# Building A2 - Lateral Package Design Basis

Northern Divide Data Campus, Building A2, Lewis and Clark County, Montana.
Roof deck diaphragm, chords and collectors, precast perimeter shear walls and their
connections, for wind. Delegated design under EOR-NDDC-A2-S01 Structural Design
Criteria Revision 2 and specification 01 33 00.

**All forces, unit shears, reactions, chord forces and deflections reported in this
package are ALLOWABLE STRESS DESIGN quantities, obtained from the strength-level wind
effect by the load combination 0.6W (EOR-NDDC-A2-S01 3.3).**

## Table 1 - Values the design was built on

| item | value | source |
|---|---|---|
| Kzt | 1.19 | TS-2026-02 section 4 |
| Ke | 0.8670 | EOR-NDDC-A2-S01 4.4 with zg = 3941.02 ft from ALTA-2025-77 benchmark BM-2 |
| q_h_psf | 28.74 | EOR-NDDC-A2-S01 4.2, V = 115 mph (NDDC-AHJ-014), Kd = 0.85, at h = 28 ft |
| screen_wall_top_ft | 36.00 | SR-2026-118 5.2 and as-built federated model (panels N108-N111) |
| asbuilt_opening_panel | S14 | NDDC-A2 Federated Model 2026, opening S14-O1, field-cut after erection, not on PC-S01 |
| asd_combination | 0.6W | EOR-NDDC-A2-S01 3.3 |
| omega_d | 2.35 | CDS-B36 Note 2 |
| analysis_method | DIAPH-MT 1.0 semi-rigid diaphragm (EOR-NDDC-A2-S01 section 9), piers as springs per 5.5 and 9.4 | EOR-NDDC-A2-S01 9, AHJ letter section 3 |
| mesh_level | L2 (H = 5.0 ft) | EOR-NDDC-A2-S01 9.1, 9.7 |

## Table 2 - Governing wind scenario for each wall line

| line | governing scenario |
|---|---|
| S | W07 |
| E | W05 |
| N1 | W06 |
| W | W01 |
| N2 | W04 |
| E2 | W01 |

Governing scenario = the scenario producing the largest wall line reaction
(the load the line takes out of the diaphragm).

## Wind parameters

- Basic wind speed V = 115 mph (3-second gust), Risk Category III, Exposure C, Kd = 0.85
  (NDDC-AHJ-014 section 2). The 2024 pre-application memorandum value of 105 mph at
  Risk Category II is superseded.
- Kzt = 1.19 over the whole footprint at all elevations and azimuths (TS-2026-02 section 4),
  superseding the Kzt = 1.00 carried in Criteria Revision 0.
- Ke = exp(-0.0000362 x 3941.02) = 0.8670 using site benchmark BM-2 (ALTA-2025-77
  section 1, brass cap at the NE corner of the generator yard slab, elev. 3941.02 ft).
  Ke is not taken as 1.0.
- q(z) = 0.00256 Kz Kzt Kd Ke V^2 with Kz = 2.01 (z/900)^(2/9.5), z >= 15 ft.
  q_h = 28.74 psf at the mean roof height h = 28.00 ft (SR-2026-118 section 3).
  Velocity pressure at the top of the typical 31 ft parapet q_p = 29.37 psf; at the top
  of the 36 ft mechanical screen wall q_p = 30.31 psf.
- Enclosed building, GCpi = +/-0.18; internal pressure cancels in the net lateral force on
  the MWFRS and is excluded from the diaphragm and shear wall loads (EOR-NDDC-A2-S01 4.1).
- Wall patches: p = q_h Cp per WT-2026-07 sections 3, 5 and 6.1, on the gross panel length
  and the elevation bands B1 (0-7 ft), B2 (7-14), B3 (14-21), B4 (21-28), including door and
  louver openings (EOR-NDDC-A2-S01 6.3). Parapet patches: p = q_p GCpn with GCpn from the
  study (+1.5 windward / -1.0 leeward, interpolated on cosine of incidence); the coefficient
  already includes both faces.
- Parapet cantilever transfer: each panel spans vertically between foundation and roof deck;
  a patch with centroid z delivers R_roof = pAz/h to the roof deck and R_base = pA(1 - z/h)
  to the foundation (EOR-NDDC-A2-S01 6.4). Parapet and screen wall patches (z > h) deliver
  more than their own force to the diaphragm; this lever action is included. The screen wall
  panels N108-N111 (top 36.00 ft) deliver the largest roof-level forces in the building.
- Torsional cases W09-W12: all line loads factored by 0.75 and MT = e B |F| applied as
  in-plane nodal forces proportional to nodal tributary area and radius about the diaphragm
  area centroid, e = +/-0.15, B = 240 ft for north/south wind and 180 ft for east/west wind
  (EOR-NDDC-A2-S01 6.6).

## Analysis

- DIAPH-MT 1.0 semi-rigid diaphragm per EOR-NDDC-A2-S01 section 9, as required by the
  AHJ (NDDC-AHJ-014 section 3). No flexible (tributary) or rigid distribution is used.
- Structured square mesh over the roof bounding rectangle; cells belong where their centre
  is inside the roof outline (generator yard notch at x > 180, y > 140 removed) and outside
  the mechanical well roof opening (100-140 x 100-130 ft). Levels L1 (H = 10 ft, 396
  elements), L2 (H = 5 ft, 1584 elements), L3 (H = 2.5 ft, 6336 elements). Reported
  quantities are at L2.
- Element stress resultants Nx = EAx ex, Ny = EAy ey, Nxy = Ghat gamma with
  Ghat = 12 G'. EAx = 4/40 x 29000 = 2900 kip/ft (W24x62 girders east-west at 40 ft);
  EAy = 2.4/5 x 29000 = 13920 kip/ft (26K9 joists north-south at 5 ft), increased to
  2.4/4 x 29000 = 17400 kip/ft in zone Z22 where the joists are at 4 ft (SJ-201 Note 2).
- Piers: each panel leg is a cantilever pier fixed at the foundation, h = 28 ft,
  k = 1/(h^3/(3 Ec I) + 1.2 h/(G A)) with Ec = 4030 ksi, G = 0.40 Ec, panel thickness and
  leg length from the as-built model. The one leg narrower than 2.0 ft (S14 leg 202.5-204,
  1.5 ft, against the field-cut opening) is neglected per 5.4. Springs attach at the mesh
  node nearest each leg midpoint; co-locating springs add.
- Supports: line S, N1 and N2 piers act in the X direction; line E, E2 and W piers act in
  the Y direction (in-plane of each wall).
- Loads: roof-level line loads of 6.4 applied to the perimeter nodes of each wall line as
  the consistent nodal loads of the piecewise-linear hat functions; signed by the patch
  coefficients so that pressure acts along the wall inward normal and suction outward.
- Recovery per 9.6: element unit shear = Ghat x engineering shear strain at the element
  centre; wall line reaction = sum of its pier spring forces; chord/collector force =
  largest bar force on the line.
- Verification: the implementation reproduces the published example VE-1 (criteria 9.8):
  240 elements / 273 nodes, applied resultant 20.00 kips, reactions 10.02 / 9.98 kips,
  largest unit shear 185.5 plf, largest chord bar force 2.57 kips, largest Y displacement
  0.1668 in - all within the 11.3 tolerances of the published values.
- Mesh convergence (Convergence worksheet): line W reaction in W01 is 45.60 kips at L2
  and 45.68 kips at L3, a change of 0.17 %, within the 5 % limit of 9.7. The largest
  unit shear (a corner quantity) is reported at each level and, as the criteria notes,
  does not converge at that rate and is not used as the measure.

## Deck design

- One deck type per zone (criteria 7.1); 3 distinct types used, within the Owner's
  limit of four (OBD-NDDC-A2 4.6): D16-36/9-6 in zones Z33, Z43; D20-36/9-4 in zones Z11; D22-36/4-2 in zones Z12, Z13, Z21, Z22, Z23, Z31, Z32, Z41, Z42.
- ASD capacity = nominal shear / omega_d = nominal / 2.35 (CDS-B36 Note 2, criteria 7.2).
- G' used: tabulated value, x1.15 in zone Z22 where the deck span is 4 ft 0 in
  (CDS-B36 Note 4, SJ-201 Note 2, criteria 7.3). The adjustment is applied to stiffness
  only, never to strength.
- The governing unit shear in every zone is checked against the zone capacity over all
  twelve scenarios, including the non-converging corner elements.

## Chords, collectors and connections

- Chord lines C-S, C-N1, C-N2, C-E, C-E2, C-W and collector lines K-N2, K-E2 (generator
  yard drag) and O-S, O-N, O-W, O-E (mechanical well) per S-201 Notes 5-7. All lines take
  PL3x3/8 (KRS-CH Table 1); the largest bar force anywhere is 12.36 kips against the
  section's 33.8 kips allowable tension / 20.3 kips allowable compression (KRS-CH Note 2).
- Deck-to-panel embeds (type E1, 4.20 kips ASD each): count per panel = larger of the
  8 ft spacing rule (minimum two) and the count needed to develop the panel's roof-level
  force (KRS-CN 2.1-2.3). 134 embeds total.
- Panel base connection B1 (1.40 kip/ft) checked against every panel's ASD in-plane shear
  in every scenario; see the calculation package for the panel-by-panel check.
- Panel stability per 5.8 (0.6D + 0.6W, gross self weight, no opening deduction): 13
  panels require a T1 base tie-down assembly (88 kips ASD at a lever arm equal to the panel
  length, KRS-CN 4.2): E201, E202, E203, E204, N111, N112, N201, N202, S01, S02, W01, W02, W03.

## Cost

Installed cost of the package 210,930 USD against the Owner's cap of 310,000 USD
(OBD-NDDC-A2 4.7): deck 140,100; chords and collectors 14,190; embeds 24,790;
tie-downs 31,850. Rates: CDS-B36 Note 5, KRS-CH Note 4, KRS-CN 2.4 and 4.3.

## Conflicts between issued documents, and resolutions

1. **Basic wind speed and risk category.** The 2024 pre-application memorandum
   (superseded by NDDC-AHJ-014 section 4) used 105 mph at Risk Category II. The AHJ letter
   section 2 accepts 115 mph at Risk Category III. The AHJ letter governs; all pressures in
   this package use V = 115 mph and Risk Category III.
2. **Topographic factor.** Criteria Revision 0 carried Kzt = 1.00 pending the site study
   (and Revision 0 is archived as superseded by T-204 item 12). TS-2026-02 section 4 gives
   Kzt = 1.19 for the whole footprint and Criteria Revision 2 section 4.3 adopts it. Kzt =
   1.19 used throughout; no height reduction is taken.
3. **Panel schedule vs as-built model (screen wall height).** PC-S01 (2024, issued for
   information only per T-204 item 10) shows panels N108-N111 at top of panel 31.00 ft.
   The as-built federated model and the roof line scan (SR-2026-118 5.2) show 36.00 ft
   between x = 96 and x = 168 on the north elevation. Criteria 5.3 makes the as-built model
   govern: N108-N111 are taken at 36.00 ft, their parapet band runs from the deck (28 ft)
   to 36 ft, and the elevated velocity pressure q_p at 36 ft is used.
4. **Field-cut opening in S14.** PC-S01 shows no opening in panel S14. The as-built model
   carries opening S14-O1, an 8.0 ft x 12.0 ft field-cut opening at station 194.5-202.5,
   marked "field-cut after erection". The as-built model governs (criteria 5.3): S14 is
   divided into a 2.5 ft leg and a 1.5 ft leg; the 1.5 ft leg is neglected per criteria 5.4.
   This panel is the as-built opening panel of the design basis table.
5. **Deck span, joist spacing.** SJ-201 Note 1 states joists north-south at 5 ft 0 in on
   centre and that the deck spans east-west between joists at 6 ft 0 in; the framing plan
   S-201 note 2 repeats the 5 ft joist spacing. The explicit span statement (6 ft 0 in) is
   taken as the deck span for the typical zones, so the tabulated G' applies unadjusted
   (CDS-B36 Note 4 gives no adjustment for any span other than 4 ft). In zone Z22 the
   mechanical bay note (SJ-201 Note 2, S-201 zone note) gives joists at 4 ft 0 in and deck
   span 4 ft 0 in, so G' there is multiplied by 1.15, stiffness only.
6. **Superseded and non-applicable documents.** T-204 items 12-15 place EOR-NDDC-A2-S01
   Rev 0, A-101 Rev A, PC-S02 Rev 1 and the Hall B lateral study in the archive. Nothing in
   this package is designed to them; the Hall B study describes another building and is not
   used. The governing drawing set is A-101 / A-301 / S-201 Revision C and PC-S02 Rev 2.
7. **Internal pressure.** WT-2026-07 section 6.4 states internal pressure is not part of
   the study; criteria 4.1 directs that GCpi cancels in the net lateral force on the MWFRS.
   No internal pressure is included in any diaphragm or shear wall load in this package.
8. **Line-load direction.** Criteria 6.5 states the line load acts along the wall inward
   normal. Pressure patches (Cp > 0) are applied along the inward normal and suction patches
   (Cp < 0) along the outward normal, so windward pressure and leeward suction on opposite
   facades add in the same global direction, as the study's sign convention requires.
9. **Deflection limit.** Criteria 2 takes the more restrictive of the governing code and
   UFC 3-301-01 Table 2-1 as adopted by the Owner's Basis of Design; OBD 4.4 sets the
   precast connection detail limit at 0.55 in for every scenario and both axes. 0.55 in is
   used; it is the more restrictive value for this detail.

## Findings carried forward

- Panel E201 (line E2, station 140-150) attracts the largest in-plane shear of any panel
  (18.20 kips ASD, from the diaphragm delivering the north-edge and generator-yard loads
  into the stiff, short E2 wall at the re-entrant corner). Its B1 base connection capacity
  is 1.40 x 10 = 14.0 kips. The exceedance is reported to the Engineer of Record: criteria
  5.7 places a panel redesign outside this package, and no change available to this package
  (deck stiffness, embeds, tie-downs) removes it. All other panels pass the B1 check.
- All 13 panels flagged by the 5.8 stability check are provided with T1 tie-down assemblies
  and pass with the assembly included.
- Maximum diaphragm deflection 0.516 in (limit 0.55); maximum pier drift 0.054 in
  (limit h/400 = 0.84 in).
